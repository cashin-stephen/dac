// import React, {useState} from 'react'
// import house1 from './../images/house1.jpeg'
// import house2 from './../images/house2.jpeg'

// const Gallery = () => {

//     const [index, setIndex] = useState(0)
//     const [picList, setPicList] = useState([house1, house2])

//     return (
//         <div className='Gallery'>
//             <img className = 'GalleryPic' src={picList[index]}/>
//         </div>
//     )
// }

// export default Gallery
