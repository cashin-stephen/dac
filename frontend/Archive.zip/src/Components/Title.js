const Title = () => {

    return (
        <div class="titleBox">
            <h1 class="title">Work In Progress</h1>
            <h1 class="dot1">.</h1>
            <h1 class="dot2">.</h1>
            <h1 class="dot3">.</h1>
        </div>
        
    ) 
}

export default Title