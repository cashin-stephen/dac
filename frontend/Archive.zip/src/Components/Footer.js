const Footer = () => {

    const year = new Date().getFullYear();

    return <footer>{`DAC ${year}`}</footer>

}

export default Footer