const Footer = () => {

    const year = new Date().getFullYear();

    return <footer>{`Stephen Cashin ${year}`}</footer>

}

export default Footer